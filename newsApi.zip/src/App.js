import logo from "./logo.svg";
import "./App.css";
import { Stories } from "./component/Stories";

function App() {
  return (
    <div className="App">
      {/* <h2>This is News using API</h2> */}
      <h2>News Platform</h2>

      <Stories />
    </div>
  );
}

export default App;
